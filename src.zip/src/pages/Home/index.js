import React from "react";
import HomeSlider from "./slider/index";
import Tempbody from "../../components/Body/tempbody";

const home = () => {
  console.log("Rendering HomeSlider...");
  return <HomeSlider />;
  return <Tempbody />;
};

export default home;
