import React from "react";
import HomeSlider from "./slider/index";
import CatSlider from "../../components/catSlider";
import "./styles.css";

import Product from "../../components/product";

const home = () => {
  //console.log("Rendering HomeSlider...");
  return (
    <>
      <HomeSlider />
      <CatSlider />

      <section className="homeProducts">
        <div className="container-fluid">
          <div className="d-flex align-items-center">
            <h2 className="hd mb-0 mt-0">Products</h2>
          </div>
          <div className="row productRow">
            <div className="item">
              <Product />
            </div>
            <div className="item">
              <Product />
            </div>
            <div className="item">
              <Product />
            </div>
            <div className="item">
              <Product />
            </div>
            <div className="item">
              <Product />
            </div>
            <div className="item">
              <Product />
            </div>
            <div className="item">
              <Product />
            </div>
            <div className="item">
              <Product />
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default home;
